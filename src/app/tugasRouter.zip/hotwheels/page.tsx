"use client";
import React from 'react';
import { useRouter } from "next/navigation";

export default function halaman_produk() {
  const router = useRouter ()
  return (
    <div>
      <h1>Selamat Datang di Koleksi Hotwheels</h1>
    </div>
  )
}
    